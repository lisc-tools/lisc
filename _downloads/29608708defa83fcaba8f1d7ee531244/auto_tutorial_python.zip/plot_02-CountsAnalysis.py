"""
Tutorial 02 - Counts Analysis
=============================
"""

# TODO